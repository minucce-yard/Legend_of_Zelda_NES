Legend of Zelda, The (USA).nes
Legend of Zelda, The (U) (PRG0).nes

MD-5:  337BD6F1A1163DF31BF2633665589AB0
SHA-1: DAB79C84934F9AA5DB4E7DAD390E5D0C12443FA2



Legend of Zelda, The (USA) (Rev A).nes
Legend of Zelda, The (U) (PRG1).nes

MD-5:  F4095791987351BE68674A9355B266BC
SHA-1: 3701381A82FC7D52B2DD3E8892047B30A114AB43



___________________________________________________



cave_room_timer.ips  [Rev 0, Rev 1]
*  Fix unusual wait time for cave clouds to animate



dungeon_front_room.ips  [Rev 0, Rev 1]
*  Fix first room door unlocking without key  (dungeon 1)



magic_beam_align.ips  [Rev 0, Rev 1]
*  Align beam shots with weapon positions
*  Align vertical weapon position to player sprite



overworld_hud_blink.ips  [Rev 0, Rev 1]
*  Fix disappearing status bar when entering underground rooms  (overworld map)



overworld_leave_cave.ips  [Rev 0, Rev 1]
*  Fix misplaced player sprite when leaving underground  (overworld map)



overworld_scroll_timing.ips  [Rev 0, Rev 1]
*  Fix vertical scrolling garbage pixels on status bar  (overworld map)



___________________________________________________



Commits:


6.1 - [2021-09-12]
*  build_script



6 - [2021-09-11]
*  magic_beam_align released



5 - [2021-09-09]
*  cave_room_timer released



4.1 - [2021-09-08]
*  cleanup



4 - [2021-09-07]
*  dungeon_front_room released



3 - [2021-09-06]
*  overworld_leave_cave released



2 - [2021-09-05]
*  overworld_scroll_timing released



1.1 - [2021-09-04]
*  overworld_hud_blink updated
   -  hardware compatibility



1 - [2021-09-01]
*  overworld_hud_blink released



_______________________________________________



Visit:
*  https://github.com/minucce-yard/Legend_of_Zelda_NES




Helpful:

*  fceux -- debugger
   https://github.com/tasvideos/fceux


   Mesen -- debugger
   https://github.com/SourMesen/Mesen



*  Disassembly
   https://github.com/aldonunez/zelda1-disassembly


_________________________________________________________



Compile:

*  asar assembler by Alcaro
   https://github.com/RPGHacker/asar


   xkas assembler by Near
   https://www.romhacking.net/utilities/269/
